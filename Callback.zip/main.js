
//function to display random animal noise on the HTML page
function makeTalk(animal){
  const noises = {
    cat: 'purr',
    dog: 'woof',
    cow: 'moo',
    pig: 'oink',
    lion: 'roar'
  }

  var elem = document.getElementById('animalsound');
  elem.innerHTML=`<h1>A ${animal} goes ${noises[animal]}.</h1>`;

}

//Returning random animal
function getRandom (arr) {
  return arr[Math.floor(Math.random()*arr.length)];
}

//This is the array for animals
const animals = ['cat', 'dog', 'cow', 'pig', 'lion'];
//Calling getRandom() function
const randomAnimal = getRandom(animals);

//Random animal info displays after 1 sec
setTimeout(() => {
  makeTalk(randomAnimal);
}, 1000);


/////////////////////////////////
//This is to display current date-time on the screen
setInterval(myFunction, 1000);

function myFunction() {
  let d = new Date();
  document.getElementById("displaytime").innerHTML=
  d.getHours() + ":" +
  d.getMinutes() + ":" +
  d.getSeconds();
}
///////////////////////////////////

//displaying student info
function displaystudent(studentname){

  const strength = {
    student1: 'Good in html',
    student2: 'Good in css',
    student3: 'Good in javascript',
    student4: 'Good in dom'}

console.log(studentname)
var elem1 = document.getElementById("strengths");

  elem1.innerHTML=`<h1> ${studentname} is ${strength[studentname]}.</h1>`;

}

//getting random student
function getRandomstudent (arr1) {
  return arr1[Math.floor(Math.random()*arr1.length)];
}


//This function is called on click button
function student_strengths() {

  const studentnum = ['student1', 'student2', 'student3', 'student4'];
  const randomstudent= getRandomstudent(studentnum );

  displaystudent(randomstudent);

  
}











